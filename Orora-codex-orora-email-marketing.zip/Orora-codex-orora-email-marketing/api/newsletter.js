import { getNewsletterDb, verifyAdminToken } from "../server/firebase-admin.js";
import { createMicrosoftMailer } from "../server/microsoft-mail.js";
import { createNewsletterAdminHandler } from "../server/newsletter-admin.js";

export default createNewsletterAdminHandler({
  getDb: getNewsletterDb,
  verifyToken: verifyAdminToken,
  sendMail: createMicrosoftMailer(),
});
