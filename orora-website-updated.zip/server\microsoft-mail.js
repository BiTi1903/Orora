export function createMicrosoftMailer(
  env = process.env,
  request = fetch
) {
  let cachedToken;
  let expiresAt = 0;

  return async function sendWelcome(email) {
    const tenant = env.MS_TENANT_ID;
    const client = env.MS_CLIENT_ID;
    const secret = env.MS_CLIENT_SECRET;
    const sender = env.MS_SENDER_EMAIL || "sales@ororavn.com";

    if (!tenant || !client || !secret) {
      throw new Error("mail_configuration_missing");
    }

    // Lấy access token Microsoft.
    if (!cachedToken || expiresAt <= Date.now()) {
      const response = await request(
        `https://login.microsoftonline.com/${encodeURIComponent(
          tenant
        )}/oauth2/v2.0/token`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            client_id: client,
            client_secret: secret,
            scope: "https://graph.microsoft.com/.default",
            grant_type: "client_credentials",
          }),
          signal: AbortSignal.timeout(10000),
        }
      );

      if (!response.ok) {
        throw new Error("mail_auth_failed");
      }

      const token = await response.json();

      if (!token.access_token) {
        throw new Error("mail_auth_failed");
      }

      cachedToken = token.access_token;

      expiresAt =
        Date.now() +
        Math.max(0, Number(token.expires_in || 3600) - 120) *
          1000;
    }

    // Nội dung email HTML gửi cho khách.
    const htmlContent = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#fff5f8;font-family:'Segoe UI',Arial,sans-serif">
<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(184,68,109,0.1)">
  <div style="background:linear-gradient(135deg,#fde2ec,#fff0f5);padding:40px 30px;text-align:center">
    <h1 style="font-family:Georgia,serif;font-size:32px;color:#3a1526;margin:0">ORORA</h1>
    <p style="color:#b8446d;font-size:14px;letter-spacing:2px;margin-top:8px">SKINCARE &amp; BEAUTY</p>
  </div>
  <div style="padding:40px 30px">
    <h2 style="font-family:Georgia,serif;font-size:24px;color:#3a1526;margin:0 0 16px">Chào bạn! 💕</h2>
    <p style="font-size:15px;line-height:1.8;color:#5a3a4a">Cảm ơn bạn đã đăng ký nhận tin từ <strong>ORORA</strong>!</p>
    <p style="font-size:15px;line-height:1.8;color:#5a3a4a">Chúng mình đã ghi nhận email của bạn. Từ giờ bạn sẽ là người đầu tiên biết về:</p>
    <ul style="font-size:14px;line-height:2;color:#5a3a4a;padding-left:20px">
      <li>🌸 Sản phẩm mới ra mắt</li>
      <li>🎁 Ưu đãi độc quyền dành cho subscriber</li>
      <li>✨ Tips chăm sóc da từ chuyên gia ORORA</li>
    </ul>
    <div style="text-align:center;margin:30px 0">
      <a href="https://ororavn.com" style="display:inline-block;padding:14px 36px;background:linear-gradient(135deg,#ee7fa2,#b8446d);color:#fff;text-decoration:none;border-radius:40px;font-size:14px;font-weight:500;letter-spacing:1px">Khám phá ngay →</a>
    </div>
    <p style="font-size:13px;line-height:1.8;color:#8a7a82">Nếu bạn không thực hiện đăng ký này hoặc muốn ngừng nhận tin, hãy trả lời email với nội dung "Hủy đăng ký" để ORORA hỗ trợ.</p>
  </div>
  <div style="background:#fff5f8;padding:24px 30px;text-align:center;font-size:12px;color:#b8446d">
    <p style="margin:0">© 2026 ORORA. All rights reserved.</p>
    <p style="margin:6px 0 0">sales@ororavn.com</p>
  </div>
</div>
</body></html>`;

    const response = await request(
      `https://graph.microsoft.com/v1.0/users/${encodeURIComponent(
        sender
      )}/sendMail`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${cachedToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: {
            subject: "ORORA – Cảm ơn bạn đã đăng ký nhận tin ✨",
            body: {
              contentType: "HTML",
              content: htmlContent,
            },
            toRecipients: [
              {
                emailAddress: {
                  address: email,
                },
              },
            ],
          },
          saveToSentItems: true,
        }),
        signal: AbortSignal.timeout(10000),
      }
    );

    // 202 nghĩa là Microsoft đã tiếp nhận yêu cầu gửi.
    if (response.status !== 202) {
      if (response.status === 401) {
        cachedToken = undefined;
      }

      throw new Error("mail_send_failed");
    }
  };
}
