import { SettingGroup, SelectField, StyleTypographyBlock, TypographyControls } from "./ui";
import { SPACE_OPTIONS, FONT_OPTIONS, SIZE_OPTIONS, toFullFontFamily, toBareFontFamily } from "./options";
import { DEFAULT_ABOUT, DEFAULT_STYLE, HERO_FIELD_MAP, COLLECTION_FIELD_MAP, PRODUCT_DETAIL_FIELD_MAP, FEATURES_TEXT_MAP, REVIEWS_TEXT_MAP, FOOTER_FIELD_MAP } from "./registry";

export function getCollectionSelectedData(collection, selected) {
  const meta = COLLECTION_FIELD_MAP[selected];
  if (!meta) {
    return { type: "colEmpty", data: null };
  }
  return { type: meta.type, data: collection, meta };
}


export function CollectionSettings({
  selected,
  data,
  collection,
  onChange,
  onStyleChange,
}) {
  if (!data || data.type === "colEmpty") {
    return (
      <div className="builder-empty">
        Chọn một thành phần trên preview.
      </div>
    );
  }

  const meta = data.meta;

  // Khung ảnh product card
  if (meta.type === "cardImage" || selected === "cardImage") {
    const layout =
      collection.productCardStyles?.imageLayout || {};
    const space = (label, key) => (
      <SelectField
        label={label}
        value={layout[key] ?? 0}
        options={SPACE_OPTIONS}
        suffix="px"
        onChange={(value) => onStyleChange({ [key]: Number(value) })}
      />
    );
    return (
      <>
        <SettingGroup title="Thẻ sản phẩm (ảnh + thông tin)">
          <small className="builder-help">
            Ngang / margin / padding áp dụng cả thẻ — ảnh và thông tin đi cùng.
            Chiều dọc chỉ đổi khung ảnh phía trên.
          </small>
        </SettingGroup>

        <SettingGroup title="Kích thước">
          <SelectField
            label="Chiều ngang cả thẻ"
            value={layout.widthPercent ?? 100}
            options={[60, 70, 75, 80, 85, 90, 95, 100]}
            suffix="%"
            onChange={(value) =>
              onStyleChange({ widthPercent: Number(value) })
            }
          />
          <SelectField
            label="Chiều dọc khung ảnh"
            value={layout.height ?? 0}
            options={[0, 220, 260, 280, 300, 320, 360, 400, 440, 480, 520]}
            suffix="px"
            onChange={(value) => onStyleChange({ height: Number(value) })}
          />
          <small className="builder-help" style={{ display: "block", marginTop: -6 }}>
            Chiều dọc = 0 → dùng tỷ lệ khung. Thông tin sản phẩm luôn nằm dưới ảnh.
          </small>
          <SelectField
            label="Tỷ lệ khung ảnh"
            value={layout.aspectRatio ?? "4 / 5"}
            options={["1 / 1", "3 / 4", "4 / 5", "2 / 3", "3 / 5", "16 / 9"]}
            onChange={(value) => onStyleChange({ aspectRatio: value })}
          />
          <SelectField
            label="Cách cắt ảnh"
            value={layout.objectFit ?? "cover"}
            options={["cover", "contain", "fill"]}
            onChange={(value) => onStyleChange({ objectFit: value })}
          />
        </SettingGroup>

        <SettingGroup title="Bo góc & viền">
          <SelectField
            label="Bo góc"
            value={layout.radius ?? 20}
            options={[0, 8, 12, 16, 20, 24, 28, 32, 40, 48]}
            suffix="px"
            onChange={(value) => onStyleChange({ radius: Number(value) })}
          />
          <SelectField
            label="Độ dày viền"
            value={layout.borderWidth ?? 0}
            options={[0, 1, 2, 3, 4, 5, 6, 8]}
            suffix="px"
            onChange={(value) =>
              onStyleChange({ borderWidth: Number(value) })
            }
          />
          <div className="builder-field">
            <label>Màu viền</label>
            <input
              type="color"
              value={layout.borderColor || "#ffffff"}
              onChange={(e) =>
                onStyleChange({ borderColor: e.target.value })
              }
              style={{
                width: 48,
                height: 32,
                padding: 0,
                border: "none",
                cursor: "pointer",
              }}
            />
          </div>
        </SettingGroup>

        <SettingGroup title="Padding (trên · phải · dưới · trái)">
          <div className="builder-field-row">
            {space("Trên", "paddingTop")}
            {space("Phải", "paddingRight")}
          </div>
          <div className="builder-field-row">
            {space("Dưới", "paddingBottom")}
            {space("Trái", "paddingLeft")}
          </div>
        </SettingGroup>

        <SettingGroup title="Margin (trên · phải · dưới · trái)">
          <div className="builder-field-row">
            {space("Trên", "marginTop")}
            {space("Phải", "marginRight")}
          </div>
          <div className="builder-field-row">
            {space("Dưới", "marginBottom")}
            {space("Trái", "marginLeft")}
          </div>
        </SettingGroup>
      </>
    );
  }

  const style =
    collection[meta.group]?.[meta.styleKey] || {};

  return (
    <>
      {meta.textKey && (
        <SettingGroup title="Nội dung">
          <div className="builder-field">
            <label>{meta.label}</label>
            <input
              value={collection[meta.textKey] || ""}
              onChange={(e) =>
                onChange({ [meta.textKey]: e.target.value })
              }
            />
          </div>
        </SettingGroup>
      )}

      <StyleTypographyBlock style={style} onStyleChange={onStyleChange} />

      <SettingGroup title="Gợi ý">
        <p className="builder-help" style={{ margin: 0 }}>
          {meta.group === "productCardStyles"
            ? "Kiểu chữ này áp dụng cho TẤT CẢ thẻ sản phẩm. Nội dung từng sản phẩm sửa ở mục Sản phẩm."
            : "Chỉnh chữ và kiểu cho tiêu đề khu vực Collection."}
        </p>
        {meta.sample && (
          <div
            style={{
              marginTop: 10,
              padding: 14,
              borderRadius: 10,
              border: "1px dashed #ead9e0",
              background:
                meta.styleKey === "button" ? "#d9628a" : "#fffafd",
              color: meta.styleKey === "button" ? "#fff" : undefined,
              fontFamily: style.fontFamily
                ? `"${style.fontFamily}", serif`
                : undefined,
              fontSize: style.fontSize
                ? `${style.fontSize}px`
                : undefined,
              fontWeight: style.fontWeight,
              fontStyle:
                style.italic || style.fontStyle === "italic"
                  ? "italic"
                  : "normal",
              letterSpacing:
                style.letterSpacing != null
                  ? `${style.letterSpacing}px`
                  : undefined,
              lineHeight: style.lineHeight,
              color:
                meta.styleKey === "button"
                  ? style.color || "#fff"
                  : style.color,
            }}
          >
            {meta.sample}
          </div>
        )}
      </SettingGroup>
    </>
  );
}